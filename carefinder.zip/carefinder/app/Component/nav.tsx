"use client";
import React from "react";

const NavigationBar: React.FC = () => {
  return (
    <nav className="bg-transparent">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <div className="block h-8 w-auto mr-2"></div>
            <span className="text-white text-xl font-semibold">CareFinder</span>
          </div>
          <div>
            <div className="inline-block px-4 py-2 bg-orange-500 text-white font-semibold hover:bg-orange-600">
              <a href="/api/auth/login">Login</a>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default NavigationBar;
